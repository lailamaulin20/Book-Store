<?php
require '../koneksi.php';
$data = mysqli_query($connection, "select * from transaksi where id_user=".$_POST['id_user']); 
$data =mysqli_fetch_all($data, MYSQLI_ASSOC);
echo json_encode($data);
?>