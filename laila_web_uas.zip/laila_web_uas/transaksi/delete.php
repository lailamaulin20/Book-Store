<?php
require '../koneksi.php';
$id = $_POST['id'];
$result = mysqli_query($connection, "delete from transaksi where
id=".$id);
if($result){
    $result = mysqli_query($connection, "delete from detail_transaksi where
    id_transaksi=".$id);
    if($result){
        echo json_encode([
            'status' => true,
            'message' => 'Data delete successfully'
        ]);
    }else{
        echo json_encode([
            'status' => false,
            'message' => 'Data Failed to delete'
            ]); 
    }
}else{
echo json_encode([
'status' => false,
'message' => 'Data Failed to delete'
]); 
}
?>