<?php
require '../koneksi.php';
$data = mysqli_query($connection, "select * from transaksi
where id=".$_POST['id']);
$det = mysqli_query($connection, "select * from detail_transaksi
where id_transaksi=".$_POST['id']);
$datatrans = mysqli_fetch_array($data, MYSQLI_ASSOC);
$datadettrans = mysqli_fetch_all($det, MYSQLI_ASSOC);
// echo json_encode([
//     'data'=>$datatrans,
//     'detail'=>$datadettrans,
//     ]);
echo json_encode($datadettrans);
?>