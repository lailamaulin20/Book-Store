<?php
require '../koneksi.php';
$id_user = $_POST['id_user'];
$tgl = $_POST['tgl'];
$total = $_POST['total'];
$result = mysqli_query($connection, "insert into transaksi set
id_user=$id_user, tgl='$tgl', total=$total");

if($result){
    $res = mysqli_query($connection, "Select * from transaksi ORDER BY id DESC");
    $data =mysqli_fetch_array($res, MYSQLI_ASSOC);
echo json_encode([
'status' => true,
'message' => 'Data input successfully',
'data'=>$data
]); }else{
echo json_encode([
'status' => false,
'message' => 'Data Failed to input'
]); }
?>