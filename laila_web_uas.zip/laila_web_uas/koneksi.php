<?php
$connection = new mysqli("localhost", "root", "root", "laila_uas");

?>