<?php
require '../koneksi.php';
$id_transaksi = $_POST['id_transaksi'];
$id_barang = $_POST['id_barang'];
$qty = $_POST['qty'];
$nmBrg = $_POST['nmBrg'];
$kdBrg = $_POST['kdBrg'];
$hrgBrg = $_POST['hrgBrg'];
$result = mysqli_query($connection, "insert into detail_transaksi set
id_transaksi=$id_transaksi, id_barang=$id_barang, nmBrg='$nmBrg',kdBrg='$kdBrg', qty=$qty, hrgBrg=$hrgBrg");
if($result){
echo json_encode([
'status' => true,
'message' => 'Data input successfully'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Data Failed to input'
]); }
?>