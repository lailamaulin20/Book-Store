<?php
require '../koneksi.php';
$username = $_POST['username'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];

$data = mysqli_query($connection, "select * from user where username = '".$_POST['username']."'");
$res = mysqli_fetch_array($data, MYSQLI_ASSOC);

if($res){
    echo json_encode([
    'status' => false,
    'message' => 'User Sudah Terdaftar'
    ]); 
}else{
    
    $result = mysqli_query($connection, "insert into user set
    username='$username', mobile='$mobile',password='$password'");
    
    if($result){
        echo json_encode([
        'status' => true,
        'message' => 'Registrasi berhasil'
        ]); 
            
    }else{
        
        echo json_encode([
        'status' => false,
        'message' => 'Registrasi gagal'
        ]); 
        
    }
}


?>