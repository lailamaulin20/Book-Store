<?php
require '../koneksi.php';
$username = $_POST['username'];
$password = $_POST['password'];
$data = mysqli_query($connection, "select * from user where username = '".$_POST['username']."'");
$res = mysqli_fetch_array($data, MYSQLI_ASSOC);

if($res){

        if($res['password'] == $password){
            echo json_encode([
                'status' => TRUE,
                'message' => 'Login success',
                'data' => $res
            ]);
        }else{
            echo json_encode([
            'status' => FALSE,
            'message' => 'Password Salah'
            ]);
        }
}else{
    echo json_encode([
        'status' => FALSE,
        'message' => 'Login gagal'
    ]);
}


?>