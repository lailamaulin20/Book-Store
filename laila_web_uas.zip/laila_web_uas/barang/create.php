<?php
require '../koneksi.php';
$kdBrg = $_POST['kdBrg'];
$nmBrg = $_POST['nmBrg'];
$hrgJual = $_POST['hrgJual'];
$hrgBeli = $_POST['hrgBeli'];
$stok = $_POST['stok'];
$img = $_POST['img'];
$result = mysqli_query($connection, "insert into barang set
kdBrg='$kdBrg', nmBrg='$nmBrg', hrgJual=$hrgJual, hrgBeli= $hrgBeli, stok=$stok, img='$img'");
if($result){
echo json_encode([
'status' => true,
'message' => 'Data input successfully'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Data Failed to input'
]); }
?>