<?php
$connection = new mysqli("localhost", "kuliketi_admin", "kuliketi_admin", "kuliketi_laila_uas");
$id = $_POST['id'];
$result = mysqli_query($connection, "delete from barang where
id=".$id);
if($result){
echo json_encode([
'status' => true,
'message' => 'Data delete successfully'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Data Failed to delete'
]); }
?>