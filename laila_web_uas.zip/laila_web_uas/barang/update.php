<?php
require '../koneksi.php';
$kdBrg = $_POST['kdBrg'];
$nmBrg = $_POST['nmBrg'];
$hrgJual = $_POST['hrgJual'];
$hrgBeli = $_POST['hrgBeli'];
$stok = $_POST['stok'];
$id = $_POST['id'];
$img = $_POST['img'];
$result = mysqli_query($connection, "update barang set
kdBrg='$kdBrg', nmBrg='$nmBrg', hrgJual=$hrgJual, hrgBeli= $hrgBeli, stok=$stok, img='$img'
where id='$id'"); if($result){
echo json_encode([
'status' => true,
'message' => 'Data edit successfully'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Data Failed to update']); }
?>